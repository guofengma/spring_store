package com.lxg.springboot.model;

public class Result {

    private String ec="000000";
    private String em="";
    
	public String getEc() {
		return ec;
	}
	public void setEc(String ec) {
		this.ec = ec;
	}
	public String getEm() {
		return em;
	}
	public void setEm(String em) {
		this.em = em;
	}
	
}
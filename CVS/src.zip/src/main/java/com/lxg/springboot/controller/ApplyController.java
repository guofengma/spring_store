package com.lxg.springboot.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lxg.springboot.mapper.ApplyMapper;
import com.lxg.springboot.mapper.FieldMapper;
import com.lxg.springboot.mapper.ShopMapper;
import com.lxg.springboot.mapper.UserMapper;
import com.lxg.springboot.model.Apply;
import com.lxg.springboot.model.ApplyIf;
import com.lxg.springboot.model.Applypage;
import com.lxg.springboot.model.Field;
import com.lxg.springboot.model.Msg;
import com.lxg.springboot.model.Order;
import com.lxg.springboot.model.Result;
import com.lxg.springboot.model.ResultUtil;
import com.lxg.springboot.model.Shop;
import com.lxg.springboot.model.Token;
import com.lxg.springboot.model.User;
import com.lxg.springboot.service.HttpAPIService;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;


@RestController
@RequestMapping("CVS/apply/")
public class ApplyController extends BaseController {
	
	@Resource
    private ApplyMapper applyMapper;
	@Resource
    private FieldMapper fieldMapper;
	@Resource
    private ShopMapper shopMapper;
	@Resource
    private UserMapper userMapper;
	@Value("${wx.appid}")
	private String appid;
	@Value("${wx.appSecret}")
	private String appSecret;
	@Resource
	private HttpAPIService httpAPIService;

    @RequestMapping("insert")
    public Msg save(Apply apply) { 
    	int i = applyMapper.querymax();
    	apply.setId(i+1);
    	if(!(apply.getField() == null || apply.getField().isEmpty())){
    		if(applyMapper.fieldcount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(apply.getField());
    		field = fieldMapper.queryfield(field);
    		apply.setAddress(field.getAddress());
    		}
    		else{
    			return ResultUtil.fail("场地提供超过10个");	
    		}
    	}
    	else if(!(apply.getDeal() == null || apply.getDeal().isEmpty())){
    		if(applyMapper.dealcount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(apply.getDeal());
    		field = fieldMapper.querydeal(field);
    		apply.setAddress(field.getAddress());
    		}
    		else{
    			return ResultUtil.fail("经营货架超过10个");	
    		}
    	}
    	else if(!(apply.getSupply() == null || apply.getSupply().isEmpty())){
    		if(applyMapper.supplycount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(apply.getSupply());
    		field = fieldMapper.querysupply(field);
    		apply.setAddress(field.getAddress());
    		}
    		else{
    			return ResultUtil.fail("供货超过10个");	
    		}
    	}
    	applyMapper.save(apply);
    	i=i+1;
    	return ResultUtil.success(i);
    }    
    
    @RequestMapping("update")
    public Result update(Apply apply) {
    	if(apply.getFieldstate() == 1 )
        	applyMapper.updatefieldstate(apply);
    	if(apply.getDealstate() == 1)
    		applyMapper.updatedealstate(apply);
    	if(apply.getSupplystate() == 1)
    		applyMapper.updatesupplystate(apply);    	
    	return new Result();
    } 
    
    @RequestMapping("updatename")
    public Result updatename(Apply apply) {
    	applyMapper.updatename(apply);
    	return new Result();
    } 
    
    @RequestMapping("opapply")
    public Msg opapply(String openid,int id,int roletype,String optype) {
    Apply apply = new Apply();
    apply.setId(id);
    if(roletype==0){
    	if(optype.equals("join")){
    		apply.setField(openid);
    		if(applyMapper.fieldcount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(openid);
    		field = fieldMapper.queryfield(field);
    		apply.setAddress(field.getAddress());
    		applyMapper.updateaddress(apply);}
    		else{
    			return ResultUtil.fail("场地提供超过10个");	
    		}
    	}
    	else{
    		apply.setField("");
    		apply.setFieldstate(0);
    		applyMapper.updatefieldstate(apply);
    	}
    	applyMapper.updatefield(apply);	
    }
    else if(roletype==1){
    	if(optype.equals("join")){
    		apply.setDeal(openid);
    		if(applyMapper.dealcount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(openid);
    		field = fieldMapper.querydeal(field);
    		apply.setAddress(field.getAddress());
    		applyMapper.updateaddress(apply);}
    		else{
    			return ResultUtil.fail("经营货架超过10个");	
    		}
    	}
    	else{
    		apply.setDeal("");
    		apply.setDealstate(0);
    		applyMapper.updatedealstate(apply);
    	}
    	applyMapper.updatedeal(apply);	
    }
    else if(roletype==2){
    	if(optype.equals("join")){
    		apply.setSupply(openid);
    		if(applyMapper.supplycount(apply)<=10) {
    		Field field = new Field();
    		field.setOpenid(openid);
    		field = fieldMapper.querysupply(field);
    		apply.setAddress(field.getAddress());
    		applyMapper.updateaddress(apply);
    		}
    		else{
    			return ResultUtil.fail("供货超过10个");	
    		}
    	}
    	else{
    		apply.setSupply("");
    		apply.setSupplystate(0);
    		applyMapper.updatesupplystate(apply);
    	}
    	applyMapper.updatesupply(apply);	
    }
    	return ResultUtil.success();
    }
        
    @RequestMapping("queryapply")
    public Applypage querybypage(Apply apply) {
    	List<Apply> applyA;  
    	int temp = 0;
    	temp = apply.getPage();
    	apply.setPage(temp*apply.getPagenum());
    	if (apply.getAddress()==null || apply.getAddress().isEmpty()){
    	applyA = applyMapper.query(apply);
    	for(int i = 0 ; i < applyA.size();i++)
    	{
    		if(applyA.get(i).getAddress() == null || applyA.get(i).getAddress().isEmpty())   			
    		{
    			applyA.get(i).setAddress("");	
    		}
    	}
    	temp = applyMapper.querypage(apply);}
    	else {
    	applyA = applyMapper.querybyad(apply);
    	temp = applyMapper.querypagead(apply);
    	}   
    	for(int i=0;i<applyA.size();i++){
    		if(!(applyA.get(i).getAddress()== null || applyA.get(i).getAddress().isEmpty())){
    		if (applyA.get(i).getAddress().length()>=5){
    			String tempA = applyA.get(i).getAddress().substring(0,8)+"...";
    			applyA.get(i).setAddress(tempA);
    		}
    		}
    		if(!(applyA.get(i).getFieldaddress()== null || applyA.get(i).getFieldaddress().isEmpty())){
    		if (applyA.get(i).getFieldaddress().length()>=5){
    			String tempA = applyA.get(i).getFieldaddress().substring(0,8)+"...";
    			applyA.get(i).setFieldaddress(tempA);
    		}
    		}
    		if(!(applyA.get(i).getDealaddress()== null || applyA.get(i).getDealaddress().isEmpty())){
    		if (applyA.get(i).getDealaddress().length()>=5){
    			String tempA = applyA.get(i).getDealaddress().substring(0,8)+"...";
    			applyA.get(i).setDealaddress(tempA);
    		}
    		}
    		if(!(applyA.get(i).getSupplyaddress()== null || applyA.get(i).getSupplyaddress().isEmpty())){
    		if (applyA.get(i).getSupplyaddress().length()>=5){
    			String tempA = applyA.get(i).getSupplyaddress().substring(0,8)+"...";
    			applyA.get(i).setSupplyaddress(tempA);
    		}}
    	}
    	Applypage applypage = new Applypage();
    	applypage.setApply(applyA);
    	applypage.setTotalpage(temp/apply.getPagenum()+1);    	
    	return applypage;
    } 
    
    @RequestMapping("query")
    public Msg query(Apply apply) {
    	Apply temp = new Apply();
    	temp = applyMapper.queryone(apply);
    	return ResultUtil.success(temp);
    } 
    
    @RequestMapping("field/insert")
    public Result fieldsave(Field field) { 
    	fieldMapper.savefield(field);
    	return new Result();
    }    
    
    @RequestMapping("field/update")
    public Result fieldupdate(Field field) {
    	fieldMapper.updatefield(field);
    	return new Result();
    } 
        
    @RequestMapping("field/query")
    public Field fieldquerybypage(Field field) {
    	Field temp = new Field();
    	temp = fieldMapper.queryfield(field);
    	return temp;
    } 

    @RequestMapping("deal/insert")
    public Result dealsave(Field deal) { 
    	fieldMapper.savedeal(deal);
        return new Result();
    }    
    
    @RequestMapping("deal/update")
    public Result dealupdate(Field deal) {
    	fieldMapper.updatedeal(deal);
        return new Result();
    } 
        
    @RequestMapping("deal/query")
    public Field dealquerybypage(Field deal) {
        Field temp = new Field();
        temp = fieldMapper.querydeal(deal);
        return temp;
    }
    
    @RequestMapping("supply/insert")
    public Result supplysave(Field supply) { 
    	fieldMapper.savesupply(supply);
        return new Result();
    }    
    
    @RequestMapping("supply/update")
    public Result supplyupdate(Field supply) {
    	fieldMapper.updatesupply(supply);
        return new Result();
    } 
        
    @RequestMapping("supply/query")
    public Field supplyquerybypage(Field supply) {
        Field temp = new Field();
        temp = fieldMapper.querysupply(supply);
        return temp;
    }
    
    @RequestMapping("Role")
    public Msg Role(Field supply) {
        Field temp = new Field();
        Field temp1 = new Field();
        Field temp2 = new Field();
        temp = fieldMapper.queryfield(supply);
        temp1 = fieldMapper.querydeal(supply);
        temp2 = fieldMapper.querysupply(supply);
        ApplyIf applyif = new ApplyIf();
        if(temp==null){
        	applyif.setField(false);
        }
        else{
        	applyif.setField(true);
        }
        if(temp1==null){
        	applyif.setDeal(false);
        }
        else{
        	applyif.setDeal(true);
        }
        if(temp2==null){
        	applyif.setSupply(false);
        }
        else{
        	applyif.setSupply(true);
        }
        return ResultUtil.success(applyif);
    }
    
    
    @RequestMapping("registerquery")
    public boolean registerquery(int id) {
    	
    	 String str_m = String.valueOf(id); 
   /*      String str ="000000";
         str_m=str.substring(0, 6-str_m.length())+str_m;*/
         
         User temp=new User();
         temp.setStoreid(str_m);
         int i = userMapper.countbosss(temp);
         if(i!=0){
         	return true;
         }
         else{
        	 str_m = String.valueOf(id); 
        	 temp.setStoreid(str_m);
        	 i = userMapper.countbosss(temp);
        	 if(i!=0){
              	return true;
              }
        	 else
        	 {
        	    return false; 
        	 }
          }
        	 
    }
    @RequestMapping("register")
    public Msg register(int id , String password ,String storename,String address) throws Exception {
        Apply apply = new Apply();
        apply.setId(id);
        apply = applyMapper.queryone(apply);
        String str_m = String.valueOf(id); 

        Field field = new Field();
		Field fieldA = new Field();
		Field deal = new Field();
		Field supply = new Field();
		field.setOpenid(apply.getField());
		deal = fieldMapper.querydeal(field);
		fieldA = fieldMapper.queryfield(field);
		supply = fieldMapper.querysupply(field);
		
		  User temp=new User();
	        temp.setPhoneno(fieldA.getPhone());
	        int i = userMapper.countbossp(temp);
	        if(i!=0){
	        	User tempUser = new User();
	        	tempUser.setPhoneno(fieldA.getPhone());
	        	List<User> userf ;
	    		userf = userMapper.querybynoboss(tempUser);
	    		String passwordtemp = userf.get(0).getPassword();
	    		if(!passwordtemp.equals(password))
	    		{
	    			return ResultUtil.fail("密码错误");
	    		}
	        }
       
        Shop shop =new Shop();
        shop.setStoreId(str_m);
        shop.setStoreName(storename);
        shop.setAddress(address);
        shop.setField(fieldA.getOpenid());
        shop.setFieldname(fieldA.getName());
        shop.setDeal(deal.getOpenid());
        shop.setDealname(deal.getName());
        shop.setSupply(supply.getOpenid());
        shop.setSupplyname(supply.getName());
    	shopMapper.insertmore(shop);
    	
    	Apply tempA = new Apply();
    	tempA.setId(id);
    	tempA.setAddress(address);
    	tempA.setStorename(storename);
    	applyMapper.updateaddress(tempA);
    	applyMapper.updatename(tempA);
    	
    	User user=new User();
    	user.setNickname(fieldA.getName());
    	user.setOpenid(fieldA.getOpenid());
    	user.setPhoneno(fieldA.getPhone());
    	user.setPassword(password);
    	user.setStoreid(str_m);
    	user.setRole("boss");
    	userMapper.saveboss(user);
    	
    	String urltoken = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&" + "appid=" + appid
				+ "&" + "secret=" + appSecret;

		Token token = JSON.parseObject(httpAPIService.doGet(urltoken), Token.class);

		String url = "https://api.weixin.qq.com/wxa/getwxacode?access_token="
				+ token.getAccess_token();

		// 参数

		// 参数
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("path","pages/index/index"+"?StoreId="+ str_m+"&StoreName="+ storename);
		map.put("width","5000");

		HashMap<String, Object> maptemp = new HashMap<String, Object>();
		maptemp.put("Jsondata", JSON.toJSONString(map));

		// 请求头
		HashMap<String, Object> header = new HashMap<String, Object>();

		byte[] data = httpAPIService.doPostImg(url, maptemp, header);

		File file =new File("/usr/share/nginx/html/images/" + str_m + ".png");
		
        OutputStream stream = new FileOutputStream(file);
        stream.write(data);
        stream.flush();
        stream.close();
        
        return ResultUtil.success();
    }
    
    @RequestMapping("authorize")
    public Msg register(String storeid,String phoneno,String password) throws Exception {
    	User temp=new User();
    	User temp1=new User();
    	temp.setStoreid(storeid);
    	temp.setRole("boss");
    	temp1 = userMapper.querybossrole(temp);
    	if (temp1.getPhoneno().equals(phoneno)){
    		return ResultUtil.fail("只能授权他人");
    	}
    	User temp3=new User();
    	temp3.setPhoneno(phoneno);
    	int i = userMapper.countbossp(temp3);
        if(i!=0){
        	User tempUser = new User();
        	tempUser.setPhoneno(phoneno);
        	List<User> userf ;
    		userf = userMapper.querybynoboss(tempUser);
    		String passwordtemp = userf.get(0).getPassword();
    		if(!passwordtemp.equals(password))
    		{
    			return ResultUtil.fail("密码错误");
    		}
        }
   
    	User user=new User();
    	user.setPhoneno(phoneno);
    	user.setPassword(password);
    	user.setStoreid(storeid);
    	user.setRole("operator");
    	try{
    	userMapper.saveboss(user);
    	}
    	catch (Exception e) {
    		return ResultUtil.fail("已经授权过");
        }
    	    
        return ResultUtil.success();
    }
    
    @RequestMapping("getshop")
    public Msg getshop(String storeid) throws Exception {
    	Shop retshop = new Shop();
    	retshop = shopMapper.querybyid(storeid);
    	
    	return ResultUtil.success(retshop);
    }
    
}

package com.lxg.springboot.mapper;

import com.lxg.springboot.model.Comment;

public interface CommentMapper {

	int save(Comment comment);
		
}